from setuptools import setup, find_packages
setup(name='eggrp',
    version='0.1',
    packages=find_packages(),
)