def test_print(x):
    for i in range(0,x):
        print('hello world %d' % i)

        